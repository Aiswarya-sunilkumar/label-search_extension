const redirectURL = chrome.identity.getRedirectURL(); 

const clientId = '970247099537-i5rf0nnf8no66redpuas0d86s2qo7e6v.apps.googleusercontent.com';
const authParams = new URLSearchParams({
  client_id: clientId,
  response_type: 'token',
  redirect_uri: redirectURL,
  scope: ['https://mail.google.com/',"https://www.googleapis.com/auth/userinfo.email"].join(' '),
});
const authURL = `https://accounts.google.com/o/oauth2/auth?${authParams.toString()}`;
chrome.identity.launchWebAuthFlow({ url: authURL, interactive: true }).then((responseUrl) => {
    const url = new URL(responseUrl);
    const urlParams = new URLSearchParams(url.hash.slice(1));
    const params = Object.fromEntries(urlParams.entries());
    var accessToken = params['access_token'];
    //chrome.strorage.local.set({'token':accessToken});
    fetch('https://www.googleapis.com/oauth2/v2/userinfo?access_token='+accessToken)
    .then(r=> r.json())
    .then(r=>{
      console.log(r.email);
      chrome.storage.local.set({ 'userId' : r.email}).then(()=> {
      // console.log("value is set to"+ r.email);
   });
    });
  
    chrome.storage.local.set({ 'token': accessToken }).then(() => {
      console.log("Value is set to " + accessToken);
    });
  });
    

//     chrome.identity.getAuthToken({interactive: true}, function(token) {
//         chrome.storage.local.set({ "token": token }).then(() => {  
//          }); 
         
//         }); 

