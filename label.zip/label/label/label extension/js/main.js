//const searchSVG =`<svg aria-labelledby="title desc" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 19.9 19.7" stroke-width="2" width="20" height="20"><g class="search-path" fill="none" stroke="#000"><path stroke-linecap="square" d="M18.5 18.3l-5.4-5.4"/><circle cx="8" cy="8" r="7"/></g></svg>`;
var newarray = [];
var sortMenuItem;
var h;
var s;
var r;
var c;
var z;
const initSortStyle = () =>{   
 sortMenuItem=document.createElement("div");
  sortMenuItem.setAttribute('class','dropdown');

    h=document.createElement("button");
    h.textContent="search"; 
    h.setAttribute('class','dropbtn');
    h.addEventListener('click',function(){ 
      document.getElementById("myDropdown").classList.toggle("show");
    });
    sortMenuItem.appendChild(h);

    s=document.createElement("div");
    s.setAttribute('class','dropdown-content');
    s.setAttribute('id','myDropdown');
    
    sortMenuItem.appendChild(s);


      r=document.createElement("input");
      r.setAttribute('type','text');
      r.setAttribute('placeholder','search label..');
      r.setAttribute('id','myInput');
      r.addEventListener('click',function(){
        getlabelName();
      });
      
      r.addEventListener('keyup',function(){
        filterFunction();
      });
      s.appendChild(r);
    
return sortMenuItem;

}

function filterFunction() {
  //var div, input, filter, a, i ,txtValue ;
 let input = document.getElementById("myInput");
 let div = document.getElementById("myDropdown");

//console.log(newarray)


 let filter = input.value.toLowerCase();
console.log(filter)
 let a = div.getElementsByTagName("a");
  for ( let i = 0; i < a.length; i++) {
   let txtValue = a[i].textContent.toLowerCase();
   // console.log(txtValue,txtValue.indexOf(filter))
   // a[i].style.display = "block";
    if (txtValue.indexOf(filter) >= 0) {
      console.log(txtValue,txtValue.indexOf(filter))
      document.querySelector('a.lnksearchkey[data-value='+txtValue+']').classList.remove('hide-element');
      //a[i].style.display = "block";
    } else {
      document.querySelector('a.lnksearchkey[data-value='+txtValue+']').classList.add('hide-element');
     // a[i].style.display = "none";
    }
  }
}


const getlabelName = () => {
  
  chrome.storage.local.get(["token"]).then((result) => {   
      let init = {
          method: 'GET',
          async: true,
          headers: {
              Authorization: 'Bearer ' + result.token,
              'Content-Type': 'application/json'
          },
          'contentType': 'json'
      };

      chrome.storage.local.get(["userId"]).then((result) => {
        c = result.userId;        
        labelEmail(c,init);
      });
  });
}
 
  function labelEmail(email,init) {
      
          fetch('https://gmail.googleapis.com/gmail/v1/users/'+email+'/labels',init)
          .then((response) => response.json())
          .then(function(data) {
  
            data.labels.forEach(element => {
              newarray.push(element.name);
            });          
            for (let index = 0; index < newarray.length; index++) {
              z=document.createElement("a");
              z.classList.add('lnksearchkey');
              z.setAttribute('data-value',newarray[index].toLowerCase());
              z.addEventListener('click',function(){
                var typeText = document.querySelector('input.gb_hf.aJh');
                typeText.value = "label:"+ newarray[index] ;
                var searchIcon = document.querySelector('.gb_qf.gb_rf');
                searchIcon.click();
              });
              z.innerHTML=newarray[index];
              s.appendChild(z);  
            
             } 
             
             s="";
            
           });
        
}


const initExtraStyling = (elem) =>{
  var dvelem3=document.createElement("div");
  dvelem3.classList.add('aAw');
  dvelem3.classList.add('FgKVne');
  dvelem3.appendChild(initSortStyle());
  elem.appendChild(dvelem3); 
}

const initSortTemplate = () => {
  var interval = setInterval(function(){
  var elem=document.querySelector('.aAw.FgKVne');
  if(elem){
  clearInterval(interval);
  initExtraStyling(elem);

}

    },100);

   
  }
const init = async () =>{
    initSortTemplate();

} 

export const main = async () => {

    await init();

}